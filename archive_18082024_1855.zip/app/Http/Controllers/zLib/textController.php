<?php

namespace App\Http\Controllers\zLib;
use App\Http\Controllers\Controller;


class textController extends Controller
{



    // public function sandboxIMG() {

    //     $path = public_path('/lib/img/sandbox/img');
    //     $img = File::files($path);

    //     return view('zTHIS.zLib.PAGE.img.sandbox', compact('img'));
    // }


    public function morda()
    {
        return view('zTHIS.zLib.PAGE.text.Text');
    }

}
 