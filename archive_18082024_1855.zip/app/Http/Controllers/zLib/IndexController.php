<?php

namespace App\Http\Controllers\zLib;
use App\Http\Controllers\Controller;

// use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
//
use App\Models\User;

class IndexController extends Controller
{


    public function imgDoc() {
        $path = public_path('/lib/img/elem/doc');
        $img = File::files($path);

        return view('zTHIS.zLib.PAGE.img.index', compact('img'));
    }

    public function imgPC() {
        $path = public_path('/lib/img/elem/pc');
        $img = File::files($path);

        return view('zTHIS.zLib.PAGE.img.index', compact('img'));
    }
 

    public function sandboxIMG() {

        $path = public_path('/lib/img/sandbox/img');
        $img = File::files($path);

        return view('zTHIS.zLib.PAGE.img.sandbox', compact('img'));
    }


    public function img()
    {
        return view('zTHIS.zLib.PAGE.img.Img');
    }

    // SVG

    public function svgMap() {
        $link = [
            '/lib/img/elem/map/full/def.svg',
            '/lib/img/elem/map/full/3.svg',
            '/lib/img/elem/map/full/1.svg',
            '/lib/img/elem/map/full/2.svg',
        ];
        return view('zTHIS.zLib.PAGE.svg.index', compact('link'));
    }



    public function sandboxSVG() {

        $path = public_path('/lib/img/sandbox/svg');
        $svg = File::files($path);

        return view('zTHIS.zLib.PAGE.svg.sandbox', compact('svg'));
    }


    
    public function svg()
    {
 
        $content_min = File::get('/home/l/laravel12/oloid.ru/resources/views/_/src/svg/min.blade.php');
        $content_lvl_1 = File::get('/home/l/laravel12/oloid.ru/resources/views/_/src/svg/lvl_1.blade.php');
        $content_market = File::get('/home/l/laravel12/oloid.ru/resources/views/_/src/svg/market.blade.php');
        $content_social = File::get('/home/l/laravel12/oloid.ru/resources/views/_/src/svg/social.blade.php');
        $content_messenger = File::get('/home/l/laravel12/oloid.ru/resources/views/_/src/svg/messenger.blade.php');
        $content_login = File::get('/home/l/laravel12/oloid.ru/resources/views/_/src/svg/login.blade.php');
        $content_manager = File::get('/home/l/laravel12/oloid.ru/resources/views/_/src/svg/manager.blade.php');
        $content_chat = File::get('/home/l/laravel12/oloid.ru/resources/views/_/src/svg/chat.blade.php');
        //
        $content_admin = File::get('/home/l/laravel12/oloid.ru/resources/views/_/src/svg/admin.blade.php');

        $svg = [
            'svg_min' => Str::replace('symbol', 'svg', $content_min),
            'svg_lvl_1' => Str::replace('symbol', 'svg', $content_lvl_1),
            'svg_market' => Str::replace('symbol', 'svg', $content_market),
            'svg_social' => Str::replace('symbol', 'svg', $content_social),
            'svg_messenger' => Str::replace('symbol', 'svg', $content_messenger),
            'svg_manager' => Str::replace('symbol', 'svg', $content_manager),
            'svg_chat' => Str::replace('symbol', 'svg', $content_chat),
            'svg_admin' => Str::replace('symbol', 'svg', $content_admin),
        ];


        return view('zTHIS.zLib.PAGE.svg.Svg', compact('svg'));
    }

 
    
    public function morda()
    {
        return view('zTHIS.zLib.Morda');
    }

}
 