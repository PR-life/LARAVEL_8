<?php

namespace App\Http\Controllers\zOloid;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

//
use App\Models\User;

class fetchController extends Controller
{
    public function index(Request $request)
    {
        dd($request);

        $data = [
            'email' => $request->input('email'),
            'phone' => $request->input('phone'),
            'whatsapp' => $request->input('whatsapp'),
            'telegram' => $request->input('telegram'),
            'viber' => $request->input('viber'),
            'lang' => $request->input('lang_sms'),
        ];

        $name = $request->get('name');
        $number = $request->get('number');



        $param2['name'] = '1111111111';

        

        $user = User::whereId('1')->get();
        $user->update($param2);



        
        return response()->json(['id' => '5555']);

        // return 5555;
        // dd(1111);
        // return view('home');
    }
}
 