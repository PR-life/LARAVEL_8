<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * The path to the "home" route for your application.
     *
     * This is used by Laravel authentication to redirect users after login.
     *
     * @var string
     */
    public const HOME = '/'; 
    public const MY = '/my/main'; 

    /**
     * The controller namespace for the application.
     *
     * When present, controller route declarations will automatically be prefixed with this namespace.
     *
     * @var string|null
     */
    protected $namespace = 'App\\Http\\Controllers';

    /**
     * Define your route model bindings, pattern filters, etc.
     *
     * @return void
     */
    public function boot()
    {
        $this->configureRateLimiting();

        $this->routes(function () {
            Route::prefix('api')
                ->middleware('api')
                ->namespace($this->namespace)
                ->group(base_path('routes/api.php'));

            Route::middleware('web')
                ->namespace($this->namespace)
                ->group(base_path('routes/web.php'));

            // Admin routes
            Route::middleware('web')
                ->namespace($this->namespace)
                ->prefix('admin')
                ->name('admin.')
                ->group(base_path('routes/ADMIN.php'));

            // My routes
            Route::middleware('web')
                ->namespace($this->namespace)
                ->prefix('my')
                ->name('my.')
                ->group(base_path('routes/MY.php'));


            // Oloid routes
            Route::middleware('web')
                ->namespace($this->namespace)
                ->name('oloid.')
                ->group(base_path('routes/zOloid.php'));


            Route::middleware('web')
                ->namespace($this->namespace)
                ->prefix('scripts')
                ->name('js.')
                ->group(base_path('routes/zJs.php'));


            Route::middleware('web')
                ->namespace($this->namespace)
                ->prefix('library')
                ->name('lib.')
                ->group(base_path('routes/zLib.php'));



        });
    }

    /**
     * Configure the rate limiters for the application.
     *
     * @return void
     */
    protected function configureRateLimiting()
    {
        RateLimiter::for('api', function (Request $request) {
            return Limit::perMinute(60)->by(optional($request->user())->id ?: $request->ip());
        });
    }
}
