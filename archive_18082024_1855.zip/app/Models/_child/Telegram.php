<?php

namespace App\Models\_child;

// use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Illuminate\Database\Eloquent\Model;
// use Illuminate\Database\Eloquent\SoftDeletes;
// use App\Models\Traits\Filterable;
// use Carbon\Carbon;
//
use App\Models\Paper;

class Telegram extends Paper
{
    protected $table = 'telegrams';


}
